// Importando as dependências
const bip32 = require('bip32');
const bip39 = require('bip39');
const bitcoin = require('bitcoinjs-lib');

// Definindo a rede
const network = bitcoin.networks.testnet;

// Criando as palavras do mnemonic para seed
const path = "m/49'/1'/0'/0";
let mnemonic = bip39.generateMnemonic();
const seed = bip39.mnemonicToSeedSync(mnemonic);

// Criando a raiz da carteira HD
let root = bip32.fromSeed(seed, network);

// Criando uma conta - par pvt-pub keys
let account = root.derivePath(path);
let node = account.derive(0).derive(0)

// Criando o endereço
let { address } = bitcoin.payments.p2pkh({
    pubkey: account.publicKey,
    network: network
});

// Exibindo os resultados
console.log("Carteira gerada");
console.log("Endereço: ", address);
console.log("Chave privada: ", account.toWIF());
console.log("Seed: ", mnemonic);
